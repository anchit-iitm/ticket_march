from flask_mail import Mail, Message


mail = Mail()