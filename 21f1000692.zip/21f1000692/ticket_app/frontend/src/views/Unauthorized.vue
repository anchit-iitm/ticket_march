<template>
    <div class="home">
      <h1>Unauthorised</h1>
      <p>Click on the button below to login</p>
      <router-link to="/login">Login</router-link>
      <p>Click on the button below to register</p>
      <router-link to="/register">Register</router-link>
    </div>
  </template>
  
  <script>
  
  export default {
    name: 'HomeView',
  }
  </script>